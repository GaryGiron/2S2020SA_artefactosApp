const dato= {
    id:Math.random(),
    estado_rest:"sin iniciar",
    cliente: "",
    estado_rep:"sin iniciar",
    entregado:0
};

module.exports=dato;